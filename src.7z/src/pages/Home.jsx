import { useAuth } from "../hooks/useAuth";

export default function Home() {
  const { user } = useAuth();

  return (
    <div style={{ padding: 20 }}>
      <h1>Home</h1>
      {user ? <p>ログイン中：{user.email}</p> : <p>ログインしていません</p>}
    </div>
  );
}
