import { collection, addDoc, getDocs } from "firebase/firestore";
import { db } from "./firebase";

export const addSampleData = (data) => {
  return addDoc(collection(db, "samples"), data);
};

export const getSampleData = async () => {
  const snapshot = await getDocs(collection(db, "samples"));
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
};
