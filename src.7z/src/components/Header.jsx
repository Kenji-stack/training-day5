import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header style={{ padding: "16px", background: "#eee" }}>
      <nav style={{ display: "flex", gap: "16px" }}>
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
      </nav>
    </header>
  );
}
