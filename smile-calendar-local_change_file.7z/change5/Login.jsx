import React, { useState } from 'react'
import { auth } from '../firebase'   // ダミー firebase
// props: onDummyLogin（App.js から受け取る）

export default function Login({ onDummyLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('login')

  const submit = async () => {
    try {
      if (mode === 'login') {
        await auth.signInWithEmailAndPassword(email, password)
        onDummyLogin(email)   // ダミーログイン反映
      } else {
        await auth.createUserWithEmailAndPassword(email, password)
        onDummyLogin(email)   // ダミー新規登録後ログイン
      }
    } catch (e) {
      alert(e.message)
    }
  }

  return (
    <div className="grid gap-3 max-w-md mx-auto">
      <h2 className="text-xl font-medium">
        {mode === 'login' ? 'ログイン' : '新規登録'}
      </h2>

      <input
        className="border p-2 rounded"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />

      <input
        className="border p-2 rounded"
        placeholder="Password"
        type="password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />

      <div className="flex gap-2">
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded"
          onClick={submit}
        >
          {mode === 'login' ? 'ログイン' : '登録'}
        </button>

        <button
          className="px-4 py-2 bg-gray-100 rounded"
          onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
        >
          {mode === 'login' ? '新規登録へ' : 'ログインへ'}
        </button>
      </div>
    </div>
  )
}
