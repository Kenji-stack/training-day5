// UI確認用のダミーFirebaseモジュール

export const auth = {
  currentUser: null,
  signInWithEmailAndPassword: () => {
    alert("【ダミー動作】ログイン成功とみなします");
    return Promise.resolve();
  },
  createUserWithEmailAndPassword: () => {
    alert("【ダミー動作】新規登録成功とみなします");
    return Promise.resolve();
  },
  signOut: () => {
    alert("【ダミー動作】ログアウト成功とみなします");
    return Promise.resolve();
  }
};

// Firestore ダミー
export const db = {
  dummy: true
};
