import React, { useEffect, useState } from 'react'

export default function DayRecord({ dateKey, record }) {
  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)

  // record を UI に反映（ダミーモードでも正常動作）
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
  }, [dateKey, record])

  // ------------------------
  // 🔻 Firestore なしのダミー保存
  // ------------------------
  const save = async () => {
    setLoading(true)

    setTimeout(() => {
      alert("【ダミー動作】保存したことにします")
      console.log("保存データ（ダミー）:", { dateKey, ...form })
      setLoading(false)
    }, 300)
  }

  // ------------------------
  // 🔻 Firestore なしのダミー削除
  // ------------------------
  const remove = async () => {
    if (!window.confirm('本当に削除しますか？')) return

    setLoading(true)

    setTimeout(() => {
      alert("【ダミー動作】削除したことにします")
      console.log("削除（ダミー）:", dateKey)
      setLoading(false)
    }, 300)
  }

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-medium mb-2">{dateKey}</h2>

      <div className="grid gap-2">

        {/* 朝の歯みがき */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingMorning}
            onChange={(e) =>
              setForm({ ...form, brushingMorning: e.target.checked })
            }
          />
          朝の歯みがき
        </label>

        {/* 昼の歯みがき */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingNoon}
            onChange={(e) =>
              setForm({ ...form, brushingNoon: e.target.checked })
            }
          />
          昼の歯みがき
        </label>

        {/* 夜の歯みがき */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingNight}
            onChange={(e) =>
              setForm({ ...form, brushingNight: e.target.checked })
            }
          />
          夜の歯みがき
        </label>

        {/* マウスウォッシュ */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.mouthwash}
            onChange={(e) =>
              setForm({ ...form, mouthwash: e.target.checked })
            }
          />
          マウスウォッシュ
        </label>

        {/* フロス */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.floss}
            onChange={(e) =>
              setForm({ ...form, floss: e.target.checked })
            }
          />
          フロス
        </label>

        {/* メモ欄 */}
        <textarea
          className="border p-2 rounded"
          rows={3}
          value={form.memo}
          onChange={(e) =>
            setForm({ ...form, memo: e.target.value })
          }
          placeholder="通院予約・通院記録・メモ"
        />
      </div>

      <div className="flex gap-2 mt-4">
        <button
          onClick={save}
          disabled={loading}
          className="px-3 py-1 bg-blue-500 text-white rounded disabled:opacity-50"
        >
          保存
        </button>

        <button
          onClick={remove}
          disabled={loading}
          className="px-3 py-1 bg-red-500 text-white rounded disabled:opacity-50"
        >
          削除
        </button>
      </div>
    </div>
  )
}
