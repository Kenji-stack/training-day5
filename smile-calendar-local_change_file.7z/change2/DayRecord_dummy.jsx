import React, { useEffect, useState } from 'react'

export default function DayRecord({ dateKey, record }) {
  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)

  // record を UI に反映（ダミーモードでも正常動作）
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
  }, [dateKey, record])

  // ------------------------
  // 🔻 Firestore なしのダミー保存
  // ------------------------
  const save = async () => {
    setLoading(true)

    setTimeout(() => {
      alert("【ダミー動作】保存したことにします")
      console.log("保存データ（ダミー）:", { dateKey, ...form })
      setLoading(false)
    }, 300)
  }

  // ------------------------
  // 🔻 Firestore なしのダミー削除
  // ------------------------
  const remove = async () => {
    if (!window.confirm('本当に削除しますか？')) return

    setLoading(true)

    setTimeout(() => {
      alert("【ダミー動作】削除したことにします")
      console.log("削除（ダミー）:", dateKey)
      setLoading(false)
    }, 300)
  }

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-medium mb-2">{dateKey}</h2>

      <div className="grid gap-2">
        <label className="inline-flex items-cen
