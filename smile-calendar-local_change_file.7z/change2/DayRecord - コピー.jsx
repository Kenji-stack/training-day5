import React, { useEffect, useState } from 'react'
import { db, auth } from '../firebase'
import { doc, setDoc, getDoc, deleteDoc } from 'firebase/firestore'

export default function DayRecord({ dateKey, record }) {
  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
  }, [dateKey, record])

  const save = async () => {
    if (!auth.currentUser) return alert('ログインしてください')
    setLoading(true)
    try {
      await setDoc(doc(db, 'oralCareRecords', dateKey), {
        uid: auth.currentUser.uid,
        date: dateKey,
        ...form,
        updatedAt: new Date()
      })
      alert('保存しました')
    } catch (e) {
      console.error(e)
      alert('保存に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  const remove = async () => {
    if (!confirm('本当に削除しますか？')) return
    setLoading(true)

    try {
      await deleteDoc(doc(db, 'oralCareRecords', dateKey))
      alert('削除しました')
    } catch (e) {
      console.error(e)
      alert('削除に失敗しました')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-medium mb-2">{dateKey}</h2>

      <div className="grid gap-2">
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.brushingMorning} onChange={e => setForm({...form, brushingMorning: e.target.checked})} />
          <span>歯磨き 朝</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.brushingNoon} onChange={e => setForm({...form, brushingNoon: e.target.checked})} />
          <span>歯磨き 昼</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.brushingNight} onChange={e => setForm({...form, brushingNight: e.target.checked})} />
          <span>歯磨き 夕</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.mouthwash} onChange={e => setForm({...form, mouthwash: e.target.checked})} />
          <span>マウスウォッシュ</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.floss} onChange={e => setForm({...form, floss: e.target.checked})} />
          <span>フロス</span>
        </label>

        <textarea className="border p-2 rounded h-28" placeholder="通院予約・通院記録・メモ" value={form.memo} onChange={e => setForm({...form, memo: e.target.value})} />

        <div className="flex gap-2">
          <button className="px-4 py-2 bg-green-500 text-white rounded" onClick={save} disabled={loading}>保存する</button>
          <button className="px-4 py-2 bg-red-400 text-white rounded" onClick={remove} disabled={loading}>削除する</button>
        </div>
      </div>
    </div>
  )
}
