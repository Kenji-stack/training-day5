import React, { useState } from 'react'
import Login from './components/Login'
import CalendarPage from './components/CalendarPage'
import { auth } from './firebase'   // ダミー Firebase

export default function App() {
  // 🔻 Firebase を使わないダミーログイン状態
  const [user, setUser] = useState(null)

  const handleLogin = (email) => {
    setUser({ email })  // ダミーのログイン状態を作る
  }

  const handleLogout = () => {
    auth.signOut()
    setUser(null)
  }

  return (
    <div className="min-h-screen flex items-start justify-center p-6">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow p-6">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-semibold">Smile Calendar System</h1>

          {user && (
            <div className="flex items-center gap-3">
              <div className="text-sm">{user.email}</div>
              <button
                className="px-3 py-1 rounded bg-gray-200"
                onClick={handleLogout}
              >
                サインアウト
              </button>
            </div>
          )}
        </header>

        <main>
          {user ? (
            <CalendarPage />
          ) : (
            <Login onDummyLogin={handleLogin} />
          )}
        </main>
      </div>
    </div>
  )
}
