import React from 'react'
import { useAuthState } from 'react-firebase-hooks/auth'
import { auth } from './firebase'
import Login from './components/Login'
import CalendarPage from './components/CalendarPage'

export default function App() {
  const [user, loading] = useAuthState(auth)

  if (loading) return <div className="p-8">読み込み中...</div>

  return (
    <div className="min-h-screen flex items-start justify-center p-6">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow p-6">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-semibold">Smile Calendar System</h1>
          {user && (
            <div className="flex items-center gap-3">
              <div className="text-sm">{user.email}</div>
              <button
                className="px-3 py-1 rounded bg-gray-200"
                onClick={() => auth.signOut()}
              >
                サインアウト
              </button>
            </div>
          )}
        </header>

        <main>
          {user ? <CalendarPage /> : <Login />}
        </main>
      </div>
    </div>
  )
}
