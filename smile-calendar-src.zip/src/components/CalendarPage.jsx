import React, { useEffect, useMemo, useState } from 'react'
import CalendarUI from './CalendarUI'
import DayRecord from './DayRecord'
import { db, auth } from '../firebase'
import { collection, query, where, onSnapshot } from 'firebase/firestore'
import { formatDateKey } from '../utils/formatDate'

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState(formatDateKey(new Date()))
  const [recordsByDate, setRecordsByDate] = useState({})

  useEffect(() => {
    if (!auth.currentUser) return
    const q = query(
      collection(db, 'oralCareRecords'),
      where('uid', '==', auth.currentUser.uid)
    )
    const unsub = onSnapshot(q, (snap) => {
      const map = {}
      snap.docs.forEach(doc => {
        map[doc.id] = doc.data()
      })
      setRecordsByDate(map)
    })

    return () => unsub()
  }, [])

  const todaysRecord = recordsByDate[selectedDate] || null
  const eventsByDate = useMemo(() => recordsByDate, [recordsByDate])

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <CalendarUI onSelectDate={setSelectedDate} recordsByDate={eventsByDate} />
      </div>
      <div>
        <DayRecord dateKey={selectedDate} record={todaysRecord} />
      </div>
    </div>
  )
}
