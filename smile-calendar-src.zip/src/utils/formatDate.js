export function formatDateKey(date) {
  if (!date) return ''
  const d = typeof date === 'string' ? new Date(date) : date
  const yyyy = d.getFullYear()
  const mm = ('0' + (d.getMonth() + 1)).slice(-2)
  const dd = ('0' + d.getDate()).slice(-2)
  return `${yyyy}-${mm}-${dd}`
}
