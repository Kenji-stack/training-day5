import { useState } from "react";
import dayjs from "dayjs";

export default function App() {
  const [currentDate, setCurrentDate] = useState(dayjs());

  const startOfMonth = currentDate.startOf("month");
  const startDay = startOfMonth.day();
  const daysInMonth = currentDate.daysInMonth();

  const prevMonth = () => setCurrentDate(currentDate.subtract(1, "month"));
  const nextMonth = () => setCurrentDate(currentDate.add(1, "month"));

  const calendarDays = [];
  for (let i = 0; i < startDay; i++) calendarDays.push("");
  for (let d = 1; d <= daysInMonth; d++) calendarDays.push(d);

  return (
    <div className="container">
      <div className="header">
        <button onClick={prevMonth} className="nav">←</button>
        <h2>{currentDate.format("YYYY年 M月")}</h2>
        <button onClick={nextMonth} className="nav">→</button>
      </div>

      <div className="weekdays">
        {["日", "月", "火", "水", "木", "金", "土"].map((day) => (
          <div key={day} className="weekday">{day}</div>
        ))}
      </div>

      <div className="days">
        {calendarDays.map((day, index) => (
          <div
            key={index}
            className={day === currentDate.date() ? "day today" : "day"}
          >
            {day}
          </div>
        ))}
      </div>
    </div>
  );
}