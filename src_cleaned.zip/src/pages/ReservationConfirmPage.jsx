import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { createReservation } from "../firebase/reservationApi";
import { useAuth } from "../context/AuthContext";

export default function ReservationConfirmPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const data = location.state?.payload || location.state;

  if (!data) {
    return (
      <div style={{ padding: 40 }}>
        <p>予約データがありません。</p>
        <button onClick={() => navigate("/reserve")}>戻る</button>
      </div>
    );
  }

  const handleSave = async () => {
    if (!currentUser) {
      alert("ログインが必要です");
      navigate("/login");
      return;
    }
    try {
      await createReservation(currentUser.uid, data);
      navigate("/reserve/complete", { state: data });
    } catch (err) {
      console.error("保存エラー:", err);
      alert("保存に失敗しました");
    }
  };

  return (
    <div style={{ padding: 40 }}>
      <h2>以下の内容で保存しますか？</h2>

      <p>日付：{data.date}</p>
      <p>タイトル：{data.title}</p>
      <p>メモ：{data.memo}</p>

      <div style={{ marginTop: 20 }}>
        <button onClick={() => navigate(-1)}>戻る</button>
        <button onClick={handleSave} style={{ marginLeft: 12 }}>
          保存
        </button>
      </div>
    </div>
  );
}
