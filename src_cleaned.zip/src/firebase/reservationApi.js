import { db } from "../firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

/**
 * createReservation(userId, reservationData)
 * reservationData should include at least an 'id' or 'date' to use as doc id.
 */
export async function createReservation(userId, reservation) {
  if (!userId) throw new Error("userId is required");
  // choose id: prefer reservation.id, fallback to date or timestamp
  const id = reservation.id || reservation.date || String(Date.now());
  const ref = doc(db, "users", userId, "reservations", id);

  const payload = {
    ...reservation,
    updatedAt: serverTimestamp(),
    createdAt: serverTimestamp(),
  };

  await setDoc(ref, payload, { merge: true });
  return true;
}
