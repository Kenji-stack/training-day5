// src/pages/ReservationConfirmPage.jsx
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { updateRecord } from "../firebase/reservationApi";

const ReservationConfirmPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const reservation = location.state?.reservation;

  if (!reservation) {
    return <p>予約データがありません。</p>;
  }

  const handleConfirm = async () => {
    const date = reservation.date;
    const data = {
      name: reservation.name,
      menu: reservation.menu,
      note: reservation.note,
    };

    try {
      await updateRecord(date, data);
      alert("予約を保存しました！");
      navigate("/");
    } catch (error) {
      console.error("予約保存エラー:", error);
      alert("保存に失敗しました。");
    }
  };

  return (
    <div>
      <h2>予約確認</h2>

      <p>日付: {reservation.date}</p>
      <p>名前: {reservation.name}</p>
      <p>メニュー: {reservation.menu}</p>
      <p>メモ: {reservation.note}</p>

      <button onClick={handleConfirm}>保存する</button>
      <button onClick={() => navigate(-1)}>戻る</button>
    </div>
  );
};

export default ReservationConfirmPage;
