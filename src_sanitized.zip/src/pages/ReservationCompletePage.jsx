import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function ReservationCompletePage() {
  const location = useLocation();
  const navigate = useNavigate();
  const data = location.state;

  return (
    <div style={{ padding: 40 }}>
      <h2>予約を保存しました！</h2>

      {data && (
        <div style={{ marginBottom: 20 }}>
          <p>日付：{data.date}</p>
          <p>タイトル：{data.title}</p>
          <p>メモ：{data.memo}</p>
        </div>
      )}

      <button onClick={() => navigate("/")}>カレンダーに戻る</button>
    </div>
  );
}
