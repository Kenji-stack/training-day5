import React from 'react'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import { formatDateKey } from '../utils/formatDate'

export default function CalendarUI({ onSelectDate, recordsByDate }) {
  return (
    <div>
      <Calendar
        onClickDay={(d) => onSelectDate(formatDateKey(d))}
        tileContent={({ date }) => {
          const key = formatDateKey(date)
          const record = recordsByDate && recordsByDate[key]
          if (!record) return null

          const icons = []
          if (record.brushingMorning || record.brushingNoon || record.brushingNight || record.mouthwash || record.floss) icons.push('✨')
          if (record.memo) icons.push('📝')
          if (record.memo && /通院|医院|歯科|予約/.test(record.memo)) icons.push('🏥')

          return (
            <div className="mt-1 text-xs">
              {icons.map((ic, i) => <span key={i} className="mr-1">{ic}</span>)}
            </div>
          )
        }}
      />
    </div>
  )
}
