// src/firebase/reservationApi.js
import { doc, getDoc, setDoc, deleteDoc } from "firebase/firestore";
import { auth, db } from "./index";

/**
 * 指定日の記録を取得
 */
export async function getRecord(date) {
  const user = auth.currentUser;
  if (!user) return null;

  const ref = doc(db, "users", user.uid, "records", date);
  const snap = await getDoc(ref);

  if (!snap.exists()) return null;
  return snap.data();
}

/**
 * 指定日の記録を更新（上書き保存）
 */
export async function updateRecord(date, data) {
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");

  const ref = doc(db, "users", user.uid, "records", date);

  await setDoc(ref, data, { merge: true });
  return true;
}

/**
 * 指定日の記録を削除
 */
export async function deleteRecord(date) {
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");

  const ref = doc(db, "users", user.uid, "records", date);
  await deleteDoc(ref);

  return true;
}
