// src/firebase/index.js
import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// ---- あなたの Firebase 設定 ----
const firebaseConfig = {
// REDACTED
// REDACTED
// REDACTED
// REDACTED
// REDACTED
// REDACTED
// REDACTED
};

// ---- Firebase を 1 回だけ初期化 ----
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

// ---- 各サービスをエクスポート ----
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;
