import { auth } from "../firebase";

const PROJECT_ID = "smile-calendar-system";

// ---- Firebase Functions（ローカル Emulator）URL ----
const CREATE_RESERVATION_URL =
  `http://127.0.0.1:5001/${PROJECT_ID}/us-central1/createReservation`;

const GET_RESERVATIONS_URL =
  `http://127.0.0.1:5001/${PROJECT_ID}/us-central1/getReservations`;

// ---- Create Reservation ----
export const createReservation = async (data) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const idToken = await user.getIdToken(true);

  const response = await fetch(CREATE_RESERVATION_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${idToken}`,
    },
    body: JSON.stringify({
      ...data,
      uid: user.uid,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error("API error: " + errorText);
  }

  return response.json();
};

// ---- Get Reservations ----
export const getReservations = async () => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const idToken = await user.getIdToken(true);

  const response = await fetch(GET_RESERVATIONS_URL, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${idToken}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error("API error: " + errorText);
  }

  return response.json();
};
