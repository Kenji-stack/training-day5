import { SAVE_MODE } from "../config/env";

export async function saveReservation(data) {
  if (SAVE_MODE === "local") {
    console.log("💾 ダミー保存 (local mode)");
    return { success: true, mode: "local" };
  }

  try {
    const res = await fetch("/api/saveReservation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err) {
    console.error("Firebase保存失敗", err);
    return { success: false, error: err };
  }
}
